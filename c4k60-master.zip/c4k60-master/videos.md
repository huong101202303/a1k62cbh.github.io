---
layout: default
title: Videos
permalink: /videos/
vd: active
---
<h3><i class="fas fa-video"></i> Videos</h3>
<br>
<h4>Phỏng vấn các C4K60ers về ngày 20/10</h4>
<iframe width="560" height="315" src="https://www.youtube.com/embed/HtZXvEpszVE" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br>
<br>
<h4>Quảng cáo xe điện PEGA Cap A9</h4>
<iframe width="560" height="315" src="https://www.youtube.com/embed/eGu405cksdQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br>
<br>
<h4>Một ngày giới thiệu các bạn cùng lớp🤣📕🖌</h4>
<iframe width="560" height="315" src="https://www.youtube.com/embed/vWdoEOZHV8Q" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>