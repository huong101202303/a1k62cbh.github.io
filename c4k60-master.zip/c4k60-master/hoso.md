---
layout: hoso
title: Hồ sơ
permalink: /hoso/
tc: active
hs: active
---
<style>
.navbar-brand{
font-size: 2rem;
}
</style>
<h3><i class="fas fa-search"></i> Tra cứu hồ sơ học sinh</h3>
<br>
 