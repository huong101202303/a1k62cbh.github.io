---
layout: default
title: Điểm thi
permalink: /diemthi/
tc: active
dt: active
---
<style>
.navbar-brand{
font-size: 2rem;
}
</style>
<h3><i class="fas fa-search"></i> Tra cứu điểm thi học kỳ 2 - Lớp 10 Chuyên Nga</h3>
        
<div class='container mt-3' style='width:100%'>
  <table class="table table-bordered table-striped">
<thead><tr><th rowspan="2">STT</th><th rowspan="2">Họ và tên</th><th colspan="5">Điểm thi học kỳ 2</th></tr></thead><tbody>
 <tr><td>&nbsp;</td><td>&nbsp;</td><th>Toán</th><th>Ngữ Văn</th><th>Lịch Sử</th><th>Địa Lý</th><th>GDCD</th></tr>
 <tr><td>1</td><td>Dương Huyền Anh</td><td>9,2</td><td>8,5</td><td>8</td><td>9</td><td>8,5</td></tr>
 <tr><td>2</td><td>Dương Tùng Anh</td><td>6</td><td>7</td><td>7,5</td><td>8</td><td>7,25</td></tr>
 <tr><td>3</td><td>Ngô Phương Anh</td><td>6,8</td><td>8</td><td>8</td><td>8,75</td><td>8</td></tr>
 <tr><td>4</td><td>Nguyễn Đạt Thái Dương</td><td>7,4</td><td>6</td><td>7</td><td>9</td><td>6,5</td></tr>
 <tr><td>5</td><td>Nguyễn Đặng Hải</td><td>8,2</td><td>8</td><td>7,5</td><td>9,5</td><td>8</td></tr>
 <tr><td>6</td><td>Nguyễn Anh Bảo Hân</td><td>6,6</td><td>8</td><td>8</td><td>9,75</td><td>8</td></tr>
 <tr><td>7</td><td>Bùi Thu Hiền</td><td>8</td><td>6,5</td><td>7,5</td><td>9</td><td>7,5</td></tr>
 <tr><td>8</td><td>Nguyễn Thuý Hiền</td><td>7,6</td><td>7,5</td><td>8</td><td>8,75</td><td>7,5</td></tr>
 <tr><td>9</td><td>Phạm Thu Hiền</td><td>6,2</td><td>7</td><td>8,25</td><td>7,75</td><td>8</td></tr>
 <tr><td>10</td><td>Hồ Trung Hiếu</td><td>8,2</td><td>8,5</td><td>5,75</td><td>8</td><td>6,75</td></tr>
 <tr><td>11</td><td>Phạm Bảo Sơn Hoa</td><td>7,6</td><td>7,5</td><td>6,25</td><td>7,5</td><td>7,5</td></tr>
 <tr><td>12</td><td>Dư Thanh Hoài</td><td>6,4</td><td>7,5</td><td>7</td><td>9,5</td><td>8,25</td></tr>
 <tr><td>13</td><td>Lã Kim Huệ</td><td>7,6</td><td>8</td><td>7</td><td>9</td><td>6,5</td></tr>
 <tr><td>14</td><td>Phạm Thị Thiên Hương</td><td>7,4</td><td>7</td><td>6,25</td><td>8</td><td>8</td></tr>
 <tr><td>15</td><td>Nguyễn Quang Huy</td><td>5,6</td><td>6</td><td>4,75</td><td>8</td><td>7</td></tr>
 <tr><td>16</td><td>Trần Thị Diệu Huyền</td><td>8</td><td>7</td><td>8</td><td>8,25</td><td>7</td></tr>
 <tr><td>17</td><td>Nguyễn Minh Khôi</td><td>7,6</td><td>6</td><td>7,75</td><td>6,5</td><td>7</td></tr>
 <tr><td>18</td><td>Lê Hoàng Tùng Lâm</td><td>&nbsp;</td><td>6</td><td>6,75</td><td>8,25</td><td>7,25</td></tr>
 <tr><td>19</td><td>Lê Kim Liên</td><td>8</td><td>8</td><td>8</td><td>9,5</td><td>6,5</td></tr>
 <tr><td>20</td><td>Đinh Thuỳ Linh</td><td>7,4</td><td>8</td><td>8</td><td>10</td><td>8,5</td></tr>
 <tr><td>21</td><td>Nguyễn Khánh Linh</td><td>7,2</td><td>8</td><td>7,75</td><td>9</td><td>7</td></tr>
 <tr><td>22</td><td>Bùi Ngọc Lĩnh</td><td>6,8</td><td>8,5</td><td>7,75</td><td>9,75</td><td>8,25</td></tr>
 <tr><td>23</td><td>Nguyễn Đức Mạnh</td><td>6</td><td>7</td><td>8</td><td>6,75</td><td>8</td></tr>
 <tr><td>24</td><td>Đỗ Thảo Nguyên</td><td>8</td><td>7,5</td><td>8</td><td>9</td><td>8,5</td></tr>
 <tr><td>25</td><td>Đào Thu Phương</td><td>6,6</td><td>7,5</td><td>7,5</td><td>7,25</td><td>9</td></tr>
 <tr><td>26</td><td>Đỗ Hồng Quân</td><td>6</td><td>5</td><td>4,25</td><td>7,75</td><td>6,5</td></tr>
 <tr><td>27</td><td>Vũ Minh Quang</td><td>5</td><td>6,5</td><td>7,25</td><td>9,25</td><td>7,5</td></tr>
 <tr><td>28</td><td>Đan Thị Phương Thảo</td><td>7,2</td><td>8,5</td><td>8,5</td><td>9,5</td><td>9,25</td></tr>
 <tr><td>29</td><td>Dương Phương Thảo</td><td>6,2</td><td>8</td><td>6,5</td><td>8</td><td>8,25</td></tr>
 <tr><td>30</td><td>Nguyễn Minh Thư</td><td>7,2</td><td>7,5</td><td>6,75</td><td>8,75</td><td>8,5</td></tr>
 <tr><td>31</td><td>Vũ Huyền Trang</td><td>7,6</td><td>8</td><td>7,5</td><td>7,75</td><td>7,5</td></tr>
 <tr><td>32</td><td>Nguyễn Thị Ánh Tuyết</td><td>9,6</td><td>8</td><td>8,5</td><td>9,75</td><td>8</td></tr>
 <tr><td>33</td><td>Trần Khánh Vân</td><td>7</td><td>7</td><td>8</td><td>9,75</td><td>8</td></tr>
 <tr><td>34</td><td>Hà Gia Văn</td><td>6,8</td><td>7</td><td>5</td><td>8,25</td><td>5,5</td></tr>
</tbody></table>

<div class='alert alert-info'>
  <strong>Thông tin:</strong> Công cụ được phát triển bởi <a class='alert-link' href='https://facebook.com/tunnaduong'>Dương Tùng Anh</a>. Nếu có bất kỳ thắc mắc, vấn đề cần giải quyết please p.m me i will help u :)
</div>
