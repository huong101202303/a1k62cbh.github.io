---
layout: default
title: Games
permalink: /games/
games: active
---
 <div class="alert alert-warning alert-dismissible fade show" id="warning-alert">
  <button type="button" class="close" data-dismiss="alert">&times;</button>
  <strong><i class="fas fa-info-circle"></i> Nhắc bạn:</strong> Đừng quên làm bài tập về nhà trước khi chơi game! :) Chúng tôi không chịu trách nhiệm nếu hôm sau bạn thiếu bài về nhà vì mải chơi game. Truy cập tại <a href="/baitap">đây</a> để xem bài tập về nhà.
</div>
<h3><i class="fas fa-gamepad"></i> Games</h3>
<br>
<center style="    width: 704px;
    height: 160px;">
	<a href="/games/zigzag">
<img src="https://s3-eu-west-1.amazonaws.com/wanted5games-games-live/game-img/7960.png" alt="Zig Zag Line" style="border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 200px; margin-right:10px;
margin-bottom: 100px;">
</a>
<a href="/games/roadfury">
<img src="https://s3-eu-west-1.amazonaws.com/wanted5games-games-live/game-img/7905.png" alt="Road Fury" style="border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 200px; margin-right:10px;
margin-bottom: 100px;">
</a>
<a href="/games/knifesmash">
<img src="https://s3-eu-west-1.amazonaws.com/wanted5games-games-live/game-img/7916.png" alt="Knife Smash" style="border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 200px; margin-right:10px;
margin-bottom: 100px;">
</a>
</center>
<center style="    width: 704px;
    height: 160px;">
	<a href="/games/ludolegend">
<img src="	https://s3-eu-west-1.amazonaws.com/wanted5games-games-live/game-img/7745.png" alt="Ludo Legend" style="border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 200px; margin-right:10px;
margin-bottom: 100px;">
</a>
	<a href="/games/templequest">
<img src="	https://s3-eu-west-1.amazonaws.com/wanted5games-games-live/game-img/7850.png" alt="Temple Quest" style="border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 200px; margin-right:10px;
margin-bottom: 100px;">
</a>
	<a href="/games/chubbybirds">
<img src="	https://s3-eu-west-1.amazonaws.com/wanted5games-games-live/game-img/7753.png" alt="Chubby Birds" style="border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 200px; margin-right:10px;
margin-bottom: 100px;">
</a>
</center>
<center style="    width: 704px;
    height: 160px;">
    <a href="/games/egyptstonewar">
<img src="	https://s3-eu-west-1.amazonaws.com/wanted5games-games-live/game-img/6683.png" alt="Egypt Stone War" style="border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 200px; margin-right:10px;
margin-bottom: 100px;">
</a>
    <a href="/games/pizzaninja3">
<img src="	https://s3-eu-west-1.amazonaws.com/wanted5games-games-live/game-img/6812.png" alt="Pizza Ninja 3" style="border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 200px; margin-right:10px;
margin-bottom: 100px;">
</a>
    <a href="/games/jewelexplode">
<img src="	https://s3-eu-west-1.amazonaws.com/wanted5games-games-live/game-img/7028.png" alt="Jewel Explode" style="border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 200px; margin-right:10px;
margin-bottom: 100px;">
</a>
</center>
<center style="width: 704px;
    height: 160px;">
<a href="/games/castledefense">
<img src="https://s3-eu-west-1.amazonaws.com/wanted5games-games-live/game-img/7685.png" alt="Castle Defense" style="border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 200px; margin-right:10px;
margin-bottom: 100px;">
</a>
<a href="/games/funnyearsurgery">
<img src="https://s3-eu-west-1.amazonaws.com/wanted5games-games-live/game-img/8001.png" alt="Funny Ear Surgery" style="border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 200px; margin-right:10px;
margin-bottom: 100px;">
</a>
    </center>
<br/>