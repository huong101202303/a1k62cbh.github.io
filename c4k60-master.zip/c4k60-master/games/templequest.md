---
layout: default
title: Temple Quest - Games C4K60
permalink: /games/templequest/
games: active
---
 <div class="alert alert-warning alert-dismissible fade show" id="warning-alert">
  <button type="button" class="close" data-dismiss="alert">&times;</button>
  <strong><i class="fas fa-info-circle"></i> Nhắc bạn:</strong> Đừng quên làm bài tập về nhà trước khi chơi game! :) Chúng tôi không chịu trách nhiệm nếu hôm sau bạn thiếu bài về nhà vì mải chơi game. Truy cập tại <a href="/baitap">đây</a> để xem bài tập về nhà.
</div>
<h3><i class="fas fa-gamepad"></i> Games</h3>
<br>
<center>
<iframe src="https://wanted5games.com/games/html5/temple-quest-new-en-s-iga-cloud/index.html?pub=10" name="cloudgames-com" width="1097" height="737" frameborder="0" scrolling="no"></iframe>
</center>